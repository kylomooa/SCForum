//
//  SCForumViewController.h
//  BaitingMember
//
//  Created by maoqiang on 30/03/2017.
//  Copyright © 2017 Goose. All rights reserved.
//

@class SCScrollViewController;
#import "SCScrollViewController.h"

@interface SCForumViewController : SCScrollViewController
@property (nonatomic, strong)SCUser *user;
@end
