//
//  SCForumModule.h
//  BaitingMember
//
//  Created by maoqiang on 26/05/2017.
//  Copyright © 2017 Goose. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCForumModule : NSObject

@end
