//
//  SCForumPostDetailViewController.h
//  BaitingMember
//
//  Created by maoqiang on 11/04/2017.
//  Copyright © 2017 Goose. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCForumPostDetailViewController : UIViewController
@property (nonatomic, copy)NSString *tid;
@property (nonatomic, assign)NSIndexPath *indexPath;

@end
